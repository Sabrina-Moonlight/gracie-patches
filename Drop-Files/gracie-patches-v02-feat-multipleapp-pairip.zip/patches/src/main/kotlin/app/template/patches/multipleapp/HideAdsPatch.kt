package app.template.patches.multipleapp

import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.returnEarly
import app.template.patches.shared.misc.pairip.MULTIPLE_APP

/**
 * Ads when entering a clone go through rt (AdMob interstitial / app-open).
 *
 * Flow:
 *   h() / k4 → c() "is ready?" → g() requestShowInternal → e() real show
 *
 * We force "not ready", block show, and skip load so opening a clone continues
 * without a full-screen ad.
 */
@Suppress("unused")
val hideAdsPatch = bytecodePatch(
    name = "Hide Ads",
    description = "Removes interstitial and app-open ads that appear when opening a clone.",
    default = true,
) {
    compatibleWith(MULTIPLE_APP)

    dependsOn(disablePairipPatch)

    execute {
        AdReadyFingerprint.method.addInstructions(
            0,
            """
                const/4 v0, 0x0
                return v0
            """,
        )

        RequestShowAdFingerprint.method.returnEarly()
        InterstitialLoadFingerprint.method.returnEarly()
        AppOpenLoadFingerprint.method.returnEarly()
    }
}
